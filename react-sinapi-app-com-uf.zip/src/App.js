
import React, { useEffect, useState } from "react";
import { fetchComposicoes } from "./api/composicoes";

const App = () => {
  const [composicoes, setComposicoes] = useState({});
  const [uf, setUf] = useState("SP");

  useEffect(() => {
    const loadData = async () => {
      const data = await fetchComposicoes();
      setComposicoes(data);
    };
    loadData();
  }, []);

  const estados = ["AC","AL","AM","AP","BA","CE","DF","ES","GO","MA","MG","MS","MT","PA","PB","PE","PI","PR","RJ","RN","RO","RR","RS","SC","SE","SP","TO"];

  return (
    <div style={{ padding: "1rem", fontFamily: "sans-serif" }}>
      <h2>Composições SINAPI</h2>

      <label>
        UF:{" "}
        <select value={uf} onChange={(e) => setUf(e.target.value)}>
          {estados.map((estado) => (
            <option key={estado} value={estado}>
              {estado}
            </option>
          ))}
        </select>
      </label>

      <ul>
        {Object.entries(composicoes).map(([codigo, comp]) => (
          <li key={codigo}>
            <strong>Família {codigo}: {comp.descricao}</strong>
            <ul>
              {comp.itens.map((item, idx) => (
                <li key={idx}>
                  {item.descricao_insumo} ({item.unidade}) - {uf}: {item.coeficientes[uf] ?? "N/A"}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
