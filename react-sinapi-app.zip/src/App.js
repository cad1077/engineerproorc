
import React, { useEffect, useState } from "react";
import { fetchComposicoes } from "./api/composicoes";

const App = () => {
  const [composicoes, setComposicoes] = useState({});

  useEffect(() => {
    const loadData = async () => {
      const data = await fetchComposicoes();
      setComposicoes(data);
    };
    loadData();
  }, []);

  return (
    <div style={{ padding: "1rem" }}>
      <h2>Composições SINAPI</h2>
      <ul>
        {Object.entries(composicoes).map(([codigo, comp]) => (
          <li key={codigo}>
            <strong>Família {codigo}</strong>
            <ul>
              {comp.itens.map((item, idx) => (
                <li key={idx}>
                  {item.descricao_insumo} ({item.unidade}) - SP: {item.coeficientes.SP}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
